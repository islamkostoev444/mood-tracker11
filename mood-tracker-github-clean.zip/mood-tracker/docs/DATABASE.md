# Схема базы данных

![Схема трёх таблиц](schema.png)

```mermaid
erDiagram
    users ||--o{ daily_entries : "заполняет"
    daily_entries ||--o{ entry_revisions : "имеет версии"
    users {
        bigint telegram_id PK
        bigint chat_id
        text timezone
        time reminder_time
        boolean reminders_enabled
        date last_reminded_on
        timestamptz created_at
    }
    daily_entries {
        bigint id PK
        bigint user_id FK
        date entry_date "UNIQUE вместе с user_id"
        smallint mood "1–5"
        numeric productive_hours "0–24"
        numeric sleep_hours "0–24"
        text comment "до 1000 символов"
        timestamptz created_at
        timestamptz updated_at
    }
    entry_revisions {
        bigint id PK
        bigint entry_id FK
        timestamptz changed_at
        smallint mood
        numeric productive_hours
        numeric sleep_hours
        text comment
    }
```

`PK` — первичный ключ, `FK` — внешний ключ. Один пользователь имеет много дневных записей; одна дневная запись имеет много версий. В текущей записи находятся последние значения, в версиях — снимки каждого успешного сохранения через бота.

`UNIQUE(user_id, entry_date)` разрешает одну запись на день и создаёт индекс для выборки статистики конкретного пользователя по датам. Дополнительный индекс `(entry_id, changed_at)` ускоряет историю изменений. Ограничения `CHECK` проверяют шкалу настроения, часы и длину комментария. Дата хранится как `DATE`, время технических событий — как `TIMESTAMPTZ`.

При удалении дневной записи её версии удаляются благодаря `ON DELETE CASCADE`. `/clear` сохраняет пользователя и настройки, но удаляет его дневные записи и версии. Незавершённый диалог находится в памяти Python, не в БД.

## Примеры SQL для ученика

После ручного импорта `test_data.sql` можно выполнить:

```sql
-- Все учебные дни. Для настоящего пользователя подставьте его Telegram ID.
SELECT entry_date, mood, productive_hours, sleep_hours
FROM daily_entries
WHERE user_id = 900000000000000001
ORDER BY entry_date;

-- Дни с максимальным настроением.
SELECT entry_date, mood
FROM daily_entries
WHERE user_id = 900000000000000001
  AND mood = (
    SELECT MAX(mood) FROM daily_entries
    WHERE user_id = 900000000000000001
  );

-- Есть ли линейная связь между сном и продуктивностью?
SELECT CORR(sleep_hours::float8, productive_hours::float8) AS correlation
FROM daily_entries
WHERE user_id = 900000000000000001;

-- Настроение при разной нагрузке. Усталость в нашей схеме не измеряется.
SELECT
  AVG(mood) FILTER (WHERE productive_hours >= 6) AS long_work_mood,
  AVG(mood) FILTER (WHERE productive_hours < 6) AS short_work_mood
FROM daily_entries
WHERE user_id = 900000000000000001;
```

Полная структура находится в `schema.sql`. Учебные данные вставлены SQL напрямую; их версии не создаются автоматически. Версии сохраняет `save_entry()` в Python, поэтому при самостоятельном изменении записей через SQL историю тоже нужно записывать самостоятельно.
